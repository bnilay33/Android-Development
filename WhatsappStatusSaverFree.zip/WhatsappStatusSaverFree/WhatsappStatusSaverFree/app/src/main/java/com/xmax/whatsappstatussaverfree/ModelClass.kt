package com.xmax.whatsappstatussaverfree

data class ModelClass(
    val filename:String,
    val fileUri:String
)
